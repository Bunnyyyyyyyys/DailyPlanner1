﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DailyPlanner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Form1_Load(object sender, EventArgs e)
        {

        }

        public void btnSave_Click(object sender, EventArgs e)
        {
            string date = "Date" + dateTimePicker1.Value.ToShortDateString().Replace(".", "");
            string note = txtNote.Text;

            //сохраняем заметку для выбранной даты
            Properties.Settings.Default[date] = note;
            Properties.Settings.Default.Save();

            MessageBox.Show("Заметка сохранена");
        }

        public void btnLoad_Click(object sender, EventArgs e)
        {
            string date = "Date" + dateTimePicker1.Value.ToShortDateString().Replace(".", "");

            //Загружаем заметку для выбранной даты
            if (Properties.Settings.Default[date] !=null)
            {
                txtNote.Text = Properties.Settings.Default[date].ToString();
            }
        }


        public void txtNote_TextChanged(object sender, EventArgs e)
        {

        }

        public void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
